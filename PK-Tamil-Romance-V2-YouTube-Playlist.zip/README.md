# PK — Tamil Romance V2

This version uses the user's YouTube playlist directly:

`PLgkbMiXk2kL_-kgRLV_l1jf3Ops2-jM6j`

The site uses the official YouTube IFrame Player API playlist functions, so Play/Next/Previous control the playlist rather than opening YouTube search pages.

Important: YouTube can prevent particular videos from being embedded. Those videos cannot be forced to play inside the site; use another video in the playlist if needed.

Deploy: replace the three files in the GitHub repository (`index.html`, `style.css`, `app.js`). Vercel will redeploy automatically from the main branch.
