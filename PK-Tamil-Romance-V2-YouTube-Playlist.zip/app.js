let playlist = window.PLAYLIST || [];
let player=null, ready=false, index=0;

const $=id=>document.getElementById(id);
const title=$("title"), artist=$("artist"), duration=$("duration"), elapsed=$("elapsed"), seek=$("seek"), playBtn=$("play"), hint=$("hint"), songList=$("songList");

function fmt(sec){sec=Math.max(0,Math.floor(sec||0));return `${Math.floor(sec/60)}:${String(sec%60).padStart(2,"0")}`}
function esc(s){return String(s||"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}

function renderList(){
  songList.innerHTML=playlist.map((s,i)=>`<div class="song ${i===index?"active":""}" data-i="${i}"><div class="num">${String(i+1).padStart(2,"0")}</div><div><div class="song-title">${esc(s.title)}</div><div class="song-artist">${esc(s.artist)}</div></div></div>`).join("");
  document.querySelectorAll(".song").forEach(el=>el.onclick=()=>selectSong(Number(el.dataset.i)));
}
function updateMeta(){
  // Prefer the actual title/artist reported by YouTube for the playing video.
  if(player && ready){
    const d=player.getVideoData ? player.getVideoData() : {};
    if(d.title) title.textContent=d.title;
    if(d.author) artist.textContent=d.author;
  }
  if(!title.textContent || title.textContent==="Tamil Romance"){
    const s=playlist[index]||{}; title.textContent=s.title||"Tamil Romance"; artist.textContent=s.artist||"YouTube Music playlist";
  }
  renderList();
}
function selectSong(i){
  index=i;
  if(player && ready){
    player.playVideoAt(i);
    hint.textContent="Playing through YouTube";
    updateMeta();
  }
  closeDrawer();
}
function syncIndex(){
  if(!player || !ready) return;
  const pi=player.getPlaylistIndex ? player.getPlaylistIndex() : -1;
  if(pi>=0) index=pi;
  updateMeta();
}
function onStateChange(e){
  if(e.data===YT.PlayerState.PLAYING){playBtn.textContent="Ⅱ";hint.textContent="Playing through YouTube";updateMeta()}
  else if(e.data===YT.PlayerState.PAUSED){playBtn.textContent="▶"}
  else if(e.data===YT.PlayerState.ENDED){hint.textContent="Playlist finished"}
}
function onReady(){
  ready=true;
  // Load the user's YouTube playlist directly. This is the key fix.
  player.loadPlaylist({listType:"playlist",list:window.PLAYLIST_ID,index:0});
  hint.textContent="Playlist loaded — tap play";
  setTimeout(updateMeta,1000);
}
function onYouTubeIframeAPIReady(){
  player=new YT.Player("player",{
    width:200,height:200,
    playerVars:{playsinline:1,controls:0,rel:0,origin:location.origin},
    events:{onReady:onReady,onStateChange:onStateChange,onError:()=>hint.textContent="This YouTube video cannot be embedded."}
  });
}

$("play").onclick=()=>{
  if(!ready){hint.textContent="Loading playlist…";return}
  const st=player.getPlayerState();
  if(st===YT.PlayerState.PLAYING) player.pauseVideo(); else player.playVideo();
};
$("next").onclick=()=>{if(ready){player.nextVideo();setTimeout(syncIndex,500)}};
$("prev").onclick=()=>{if(ready){player.previousVideo();setTimeout(syncIndex,500)}};
seek.oninput=()=>{if(ready){const d=player.getDuration()||0;player.seekTo((Number(seek.value)/100)*d,true)}};

setInterval(()=>{
  if(ready){
    const d=player.getDuration()||0,c=player.getCurrentTime()||0;
    elapsed.textContent=fmt(c);duration.textContent=d?fmt(d):"—";seek.value=d?(c/d*100):0;
    const pi=player.getPlaylistIndex ? player.getPlaylistIndex() : -1;
    if(pi>=0 && pi!==index){index=pi;updateMeta()}
  }
},500);

function openDrawer(){$("drawer").classList.add("open");$("scrim").classList.add("show");}
function closeDrawer(){$("drawer").classList.remove("open");$("scrim").classList.remove("show");}
$("playlistBtn").onclick=openDrawer;$("closeDrawer").onclick=closeDrawer;$("scrim").onclick=closeDrawer;

const tag=document.createElement("script");tag.src="https://www.youtube.com/iframe_api";document.head.appendChild(tag);
renderList();
